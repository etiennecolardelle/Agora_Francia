<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'client') {
    header("Location: login.php");
    exit;
}

$message = "";
$id_client = $_SESSION['user_id'];
$id_produit = $_GET['produit'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $id_produit) {
    $type = $_POST['type_carte'] ?? '';
    $numero = $_POST['numero'] ?? '';
    $nom = $_POST['nom_carte'] ?? '';
    $expiration = $_POST['date_expiration'] ?? '';
    $code = $_POST['code_securite'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM cartes_bancaires WHERE type_carte = ? AND numero = ? AND nom_carte = ? AND date_expiration = ? AND code_securite = ?");
    $stmt->execute([$type, $numero, $nom, $expiration, $code]);
    $carte = $stmt->fetch();

    if ($carte) {
        $pdo->prepare("INSERT INTO commandes (id_client, id_produit) VALUES (?, ?)" )->execute([$id_client, $id_produit]);
        $pdo->prepare("UPDATE paiements_en_attente SET paye = 1 WHERE id_client = ? AND id_produit = ?")->execute([$id_client, $id_produit]);

        // Supprimer les dépendances avant de supprimer le produit
        $stmt = $pdo->prepare("SELECT id FROM negociations WHERE id_produit = ?");
        $stmt->execute([$id_produit]);
        $negos = $stmt->fetchAll();
        foreach ($negos as $n) {
            $pdo->prepare("DELETE FROM negociation_messages WHERE id_negociation = ?")->execute([$n['id']]);
        }
        $pdo->prepare("DELETE FROM negociations WHERE id_produit = ?")->execute([$id_produit]);
        $pdo->prepare("DELETE FROM encheres WHERE id_produit = ?")->execute([$id_produit]);
        $pdo->prepare("DELETE FROM panier WHERE id_produit = ?")->execute([$id_produit]);

        $pdo->prepare("DELETE FROM produits WHERE id = ?")->execute([$id_produit]);
        unset($_SESSION['panier']);
        header("Location: achat.php?id=$id_produit");
        exit;
    } else {
        $message = "❌ Paiement refusé. Informations invalides.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Paiement</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
</head>
<body>
<h1>💳 Paiement</h1>

<?php if ($message): ?>
    <p style="color:<?= str_starts_with($message, '✅') ? 'green' : 'red' ?>;"><strong><?= $message ?></strong></p>
<?php endif; ?>

<form method="POST">
    <label>Type de carte :</label><br>
    <select name="type_carte" required>
        <option value="Visa">Visa</option>
        <option value="MasterCard">MasterCard</option>
        <option value="American Express">American Express</option>
        <option value="PayPal">PayPal</option>
    </select><br><br>

    <label>Numéro de la carte :</label><br>
    <input type="text" name="numero" required><br><br>

    <label>Nom sur la carte :</label><br>
    <input type="text" name="nom_carte" required><br><br>

    <label>Date d’expiration :</label><br>
    <input type="date" name="date_expiration" required><br><br>

    <label>Code de sécurité :</label><br>
    <input type="text" name="code_securite" maxlength="4" required><br><br>

    <button type="submit">Valider le paiement</button>
</form>

<p><?php if ($_SESSION['type'] === 'client'): ?>
        <a href="dashboard_client.php">👤 Mon tableau de bord</a>
    <?php elseif ($_SESSION['type'] === 'vendeur'): ?>
        <a href="dashboard_vendeur.php">👤 Mon tableau de bord</a>
    <?php elseif ($_SESSION['type'] === 'admin'): ?>
        <a href="dashboard_admin.php">👤 Tableau de bord admin</a>
    <?php endif; ?>
</body>
</html>
