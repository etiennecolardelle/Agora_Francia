<?php include 'verifier_encheres.php'; ?>

<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id_produit = $_GET['id'] ?? null;
if (!$id_produit) exit("Aucun produit sélectionné.");

$id_user = $_SESSION['user_id'] ?? null;
$type_user = $_SESSION['type'] ?? null;

$stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
$stmt->execute([$id_produit]);
$produit = $stmt->fetch();
if (!$produit) exit("Produit introuvable.");

$est_client = ($type_user === 'client');
$est_vendeur = ($type_user === 'vendeur' && $produit['id_vendeur'] == $id_user);
$est_proprietaire = ($id_user && $produit['id_vendeur'] == $id_user);
$message = "";

// Suppression du produit (vendeur ou admin)
if (isset($_GET['supprimer']) && $est_proprietaire) {
    try {
        $pdo->beginTransaction();

        // Supprimer les messages de négociation liés
        $stmt = $pdo->prepare("
        DELETE nm FROM negociation_messages nm
        JOIN negociations n ON nm.id_negociation = n.id
        WHERE n.id_produit = ?
    ");
        $stmt->execute([$id_produit]);

        // Supprimer les négociations
        $stmt = $pdo->prepare("DELETE FROM negociations WHERE id_produit = ?");
        $stmt->execute([$id_produit]);

        // Supprimer les enchères
        $stmt = $pdo->prepare("DELETE FROM encheres WHERE id_produit = ?");
        $stmt->execute([$id_produit]);

        // Supprimer du panier
        $stmt = $pdo->prepare("DELETE FROM panier WHERE id_produit = ?");
        $stmt->execute([$id_produit]);

        // Supprimer paiements en attente
        $stmt = $pdo->prepare("DELETE FROM paiements_en_attente WHERE id_produit = ?");
        $stmt->execute([$id_produit]);

        // Supprimer les commandes (optionnel si le produit n’est pas censé être supprimé après achat)
        $stmt = $pdo->prepare("DELETE FROM commandes WHERE id_produit = ?");
        $stmt->execute([$id_produit]);

        // Supprimer le produit
        $stmt = $pdo->prepare("DELETE FROM produits WHERE id = ? AND id_vendeur = ?");
        $stmt->execute([$id_produit, $id_user]);

        $pdo->commit();

        // Redirection selon le rôle
        if ($_SESSION['type'] === 'admin') {
            header("Location: dashboard_admin.php");
        } elseif ($_SESSION['type'] === 'client') {
            header("Location: dashboard_client.php");
        } else {
            header("Location: dashboard_vendeur.php");
        }
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        echo "❌ Erreur lors de la suppression du produit : " . $e->getMessage();
    }
}


// Traitement enchère (client)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prix_enchere']) && $produit['type_vente'] === 'enchere' && $est_client && !$est_proprietaire) {
    $prix = floatval($_POST['prix_enchere']);
    if ($prix > $produit['prix']) {
        $stmt = $pdo->prepare("INSERT INTO encheres (id_produit, id_client, prix_max) VALUES (?, ?, ?)");
        $stmt->execute([$id_produit, $id_user, $prix]);
        $message = "Votre enchère a été enregistrée.";
    } else {
        $message = "❌ L’enchère doit être supérieure ou égale au prix de départ.";
    }
}

// Historique des enchères
$historique_enchere = [];
if ($produit['type_vente'] === 'enchere') {
    $stmt = $pdo->prepare("SELECT e.prix_max, e.date_enchere, u.nom, u.prenom 
                           FROM encheres e 
                           JOIN utilisateurs u ON u.id = e.id_client 
                           WHERE e.id_produit = ?
                           ORDER BY e.date_enchere DESC");
    $stmt->execute([$id_produit]);
    $historique_enchere = $stmt->fetchAll();
}

// Traitement négociation (client)
if ($produit['type_vente'] === 'negociation' && $est_client && !$est_proprietaire) {
    $stmt = $pdo->prepare("SELECT * FROM negociations WHERE id_produit = ? AND id_client = ?");
    $stmt->execute([$id_produit, $id_user]);
    $nego = $stmt->fetch();

    if (!$nego) {
        $stmt = $pdo->prepare("INSERT INTO negociations (id_produit, id_client) VALUES (?, ?)");
        $stmt->execute([$id_produit, $id_user]);
        $nego_id = $pdo->lastInsertId();
    } else {
        $nego_id = $nego['id'];
    }

    $stmt = $pdo->prepare("SELECT * FROM negociation_messages WHERE id_negociation = ? ORDER BY date_echange ASC");
    $stmt->execute([$nego_id]);
    $historique = $stmt->fetchAll();

    $dernier = end($historique);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prix_offre']) && (!$dernier || $dernier['auteur'] === 'vendeur')) {
        $stmt = $pdo->prepare("INSERT INTO negociation_messages (id_negociation, auteur, prix) VALUES (?, 'client', ?)");
        $stmt->execute([$nego_id, floatval($_POST['prix_offre'])]);
        $message = "Votre offre a été envoyée.";
    } elseif (isset($_POST['prix_offre'])) {
        $message = "⏳ En attente de réponse du vendeur avant de proposer une nouvelle offre.";
    }

    // Paiement si accepté
    if ($nego['etat'] === 'acceptee') {
        // Vérifier si déjà en attente de paiement
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM paiements_en_attente WHERE id_client = ? AND id_produit = ?");
        $stmt->execute([$id_user, $id_produit]);
        $existe = $stmt->fetchColumn();
        if (!$existe) {
            $stmt = $pdo->prepare("INSERT INTO paiements_en_attente (id_client, id_produit, paye) VALUES (?, ?, 0)");
            $stmt->execute([$id_user, $id_produit]);
        }
        echo '<p style="color:blue;"><strong>✅ Votre offre a été acceptée. Vous pouvez procéder au paiement :</strong></p>';
        echo '<a href="paiement.php?produit=' . $id_produit . '">💳 Payer maintenant</a>';
    }
}

// Traitement négociation (vendeur)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['nego_id']) && $est_vendeur) {
    $nego_id = $_POST['nego_id'];
    if ($_POST['action'] === 'contre' && isset($_POST['contre_offre'])) {
        $prix = floatval($_POST['contre_offre']);
        $stmt = $pdo->prepare("INSERT INTO negociation_messages (id_negociation, auteur, prix) VALUES (?, 'vendeur', ?)");
        $stmt->execute([$nego_id, $prix]);
    }
    if ($_POST['action'] === 'accepter') {
        $stmt = $pdo->prepare("UPDATE negociations SET etat = 'acceptee' WHERE id = ?");
        $stmt->execute([$nego_id]);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title><?= htmlspecialchars($produit['nom']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <style>
        /* Styles rapides intégrés pour exemple, à déplacer dans style.css */
        body {
            background: linear-gradient(145deg,#7a64b8,#444b7a);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #222;
            margin: 0;
            padding: 0 1rem;
        }
        #page-top, .navbar-sticky {
            position: sticky;
            top: 0;
            background: linear-gradient(145deg,#7a64b8,#444b7a);
            z-index: 999;
            box-shadow: 0 2px 4px rgb(0 0 0 / 0.1);
        }
        main.product-detail {
            max-width: 900px;
            margin: 2rem auto;
            background: linear-gradient(145deg,#7a64b8,#444b7a);
            border-radius: 12px;
            box-shadow: 0 8px 20px rgb(0 0 0 / 0.1);
            padding: 2rem;
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
        }
        .product-image {
            flex: 1 1 300px;
            text-align: center;
        }
        .product-image img {
            max-width: 100%;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgb(0 0 0 / 0.15);
            transition: transform 0.3s ease;
            cursor: zoom-in;
        }
        .product-image img:hover {
            transform: scale(1.05);
        }
        .product-info {
            flex: 1 1 400px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .product-info h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            color: #d93f3f; /* Rouge pokémon */
            text-shadow: 1px 1px 3px #00000044;
        }
        .product-price {
            font-size: 1.5rem;
            color: #1a8917; /* Vert clair */
            font-weight: 700;
            margin-bottom: 1rem;
        }
        .product-type {
            font-style: italic;
            margin-bottom: 1rem;
            color: #444;
        }
        .product-description {
            line-height: 1.4;
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            color: #333;
        }
        .btn-buy, .btn-action {
            background: #ffcb05; /* Jaune pokémon */
            border: none;
            padding: 0.7rem 1.2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            box-shadow: 0 4px 8px #cc9b04aa;
            transition: background-color 0.3s ease;
            text-decoration: none;
            text-align: center;
            color: #222;
            display: inline-block;
            margin-bottom: 1rem;
        }
        .btn-buy:hover, .btn-action:hover {
            background: #e6b804;
            box-shadow: 0 6px 12px #cc9b0499;
        }
        hr {
            border: none;
            border-top: 2px solid #ddd;
            margin: 2rem 0;
        }
        .message-success {
            background-color: #e0f7e9;
            border-left: 6px solid #1a8917;
            padding: 1rem;
            margin-bottom: 1rem;
            font-weight: 600;
            color: #145214;
            border-radius: 6px;
        }
        ul.history-list {
            max-height: 200px;
            overflow-y: auto;
            padding-left: 1.2rem;
            color: #444;
            margin-bottom: 2rem;
        }
        ul.history-list li {
            margin-bottom: 0.3rem;
            font-size: 0.95rem;
        }
        table.history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        table.history-table th, table.history-table td {
            border: 1px solid #ccc;
            padding: 0.5rem 0.8rem;
            text-align: left;
            font-size: 0.9rem;
        }
        table.history-table th {
            background-color: #f0f0f0;
        }
        form input[type="number"] {
            padding: 0.5rem;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            width: 100%;
            max-width: 180px;
            margin-right: 1rem;
        }
        form button {
            padding: 0.5rem 1rem;
            font-size: 1rem;
            border-radius: 6px;
            border: none;
            background-color: #d93f3f;
            color: white;
            cursor: pointer;
            font-weight: 700;
            transition: background-color 0.3s ease;
        }
        form button:hover {
            background-color: #b32b2b;
        }
        .seller-info {
            font-style: italic;
            color: #666;
            margin-bottom: 1rem;
        }
        a.back-link {
            display: inline-block;
            margin-top: 2rem;
            color: #d93f3f;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        a.back-link:hover {
            color: #a02a2a;
            text-decoration: underline;
        }

        /* Responsive */
        @media(max-width: 720px) {
            main.product-detail {
                flex-direction: column;
                padding: 1rem;
            }
            .product-image, .product-info {
                flex: 1 1 100%;
            }
            form input[type="number"] {
                max-width: 100%;
                margin-bottom: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div id="page-top">
        <?php include 'includes/header.php'; ?>
    </div>

    <div class="navbar-sticky">
        <?php include 'includes/navbar.php'; ?>
    </div>

    <main class="product-detail">
        <section class="product-image">
            <?php if ($produit['image']): ?>
                <img src="<?= htmlspecialchars($produit['image']) ?>" alt="Image de <?= htmlspecialchars($produit['nom']) ?>" loading="lazy" />
            <?php else: ?>
                <div style="font-style: italic; color: #aaa;">Pas d’image disponible</div>
            <?php endif; ?>
        </section>

        <section class="product-info">
            <h1><?= htmlspecialchars($produit['nom']) ?></h1>
            <div class="product-price">Prix : <?= number_format($produit['prix'], 2) ?> €</div>
            <div class="product-type">Type de vente : <?= htmlspecialchars($produit['type_vente']) ?></div>
            <div class="product-description"><?= nl2br(htmlspecialchars($produit['description'])) ?></div>

            <?php if ($message): ?>
                <div class="message-success"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <?php if (!$est_proprietaire): ?>
                <?php if ($produit['type_vente'] === 'achat_immediat' && $est_client): ?>
                    <a class="btn-buy" href="achat.php?id=<?= $produit['id']?>">🛒 Acheter maintenant</a>

                <?php elseif ($produit['type_vente'] === 'negociation' && $est_client && $nego['etat'] !== 'acceptee'): ?>
                    <h2>💬 Négociation</h2>
                    <form method="POST" style="display:flex; flex-wrap: wrap; align-items:center; gap:0.5rem;">
                        <input type="number" step="0.01" name="prix_offre" placeholder="Votre prix en €" required />
                        <button type="submit" class="btn-action">Proposer</button>
                    </form>

                    <ul class="history-list">
                        <?php foreach ($historique as $h): ?>
                            <li><?= ucfirst(htmlspecialchars($h['auteur'])) ?> : <?= number_format($h['prix'], 2) ?> € (<?= htmlspecialchars($h['date_echange']) ?>)</li>
                        <?php endforeach; ?>
                    </ul>

                <?php elseif ($produit['type_vente'] === 'enchere' && $est_client): ?>
                    <h2>💸 Enchère</h2>
                    <form method="POST" style="display:flex; flex-wrap: wrap; align-items:center; gap:0.5rem;">
                        <label for="prix_enchere" style="font-weight:600;">Votre enchère max :</label>
                        <input id="prix_enchere" type="number" name="prix_enchere" step="0.01" required />
                        <button type="submit" class="btn-action">Enchérir</button>
                    </form>

                    <h3>📈 Historique des enchères</h3>
                    <?php if (!empty($historique_enchere)): ?>
                        <table class="history-table" aria-label="Historique des enchères">
                            <thead>
                                <tr>
                                    <th>Client</th>
                                    <th>Montant</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($historique_enchere as $enchere): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($enchere['prenom'] . ' ' . strtoupper($enchere['nom'])) ?></td>
                                        <td><?= number_format($enchere['prix_max'], 2) ?> €</td>
                                        <td><?= htmlspecialchars($enchere['date_enchere']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>Aucune enchère encore enregistrée.</p>
                    <?php endif; ?>
                <?php endif; ?>

            <?php else: ?>
                <p class="seller-info"><em>Vous êtes le vendeur de ce produit.</em></p>
                <a href="detail_produit.php?id=<?= $produit['id'] ?>&supprimer=1" 
                   onclick="return confirm('Voulez-vous vraiment supprimer ce produit ?')" 
                   class="btn-action" style="background:#cc2222;">❌ Supprimer ce produit</a>

                <?php if ($produit['type_vente'] === 'negociation' && $est_proprietaire):
                    echo "<h2>📬 Négociations en cours</h2>";
                    $stmt = $pdo->prepare("SELECT n.id AS nego_id, n.etat, u.nom, u.prenom FROM negociations n JOIN utilisateurs u ON u.id = n.id_client WHERE n.id_produit = ?");
                    $stmt->execute([$id_produit]);
                    $negos = $stmt->fetchAll();
                    foreach ($negos as $nego):
                        $stmt = $pdo->prepare("SELECT * FROM negociation_messages WHERE id_negociation = ? ORDER BY date_echange ASC");
                        $stmt->execute([$nego['nego_id']]);
                        $messages = $stmt->fetchAll();
                ?>
                    <h3>Client : <?= htmlspecialchars($nego['prenom'] . ' ' . $nego['nom']) ?></h3>
                    <ul class="history-list">
                        <?php foreach ($messages as $m): ?>
                            <li><?= ucfirst(htmlspecialchars($m['auteur'])) ?> : <?= number_format($m['prix'], 2) ?> € (<?= htmlspecialchars($m['date_echange']) ?>)</li>
                        <?php endforeach; ?>
                    </ul>

                    <?php if ($nego['etat'] !== 'acceptee'): ?>
                    <form method="POST" style="display:flex; flex-wrap: wrap; align-items:center; gap:0.5rem;">
                        <input type="hidden" name="nego_id" value="<?= $nego['nego_id'] ?>" />
                        <input type="number" step="0.01" name="contre_offre" placeholder="Contre-offre en €" />
                        <button name="action" value="contre" class="btn-action">Contre-proposer</button>
                        <button name="action" value="accepter" class="btn-action" style="background:#1a8917; color:white;">Accepter</button>
                    </form>
                    <?php else: ?>
                        <p style="color:gray; font-weight:600;">✅ Offre acceptée — négociation conclue.</p>
                    <?php endif; ?>

                <?php endforeach;
                endif; ?>

            <?php endif; ?>

            <a href="produits.php" class="back-link">← Retour</a>
        </section>
    </main>
</body>
</html>

