<?php
require 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id_client = $_SESSION['user_id'];
$message = "";

// Traitement de l'ajout d'alerte
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mot_cle = $_POST['mot_cle'] ?? '';
    $categorie = $_POST['categorie'] ?? '';
    $type_vente = $_POST['type_vente'] ?? '';

    $stmt = $pdo->prepare("INSERT INTO alertes (id_client, mot_cle, categorie, type_vente) VALUES (?, ?, ?, ?)");
    $stmt->execute([$id_client, $mot_cle, $categorie, $type_vente]);
    $message = "✅ Alerte enregistrée.";
}

// Récupérer les alertes existantes
$stmt = $pdo->prepare("SELECT * FROM alertes WHERE id_client = ?");
$stmt->execute([$id_client]);
$alertes = $stmt->fetchAll();
?>
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mes alertes</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
</head>
<body>
<h1>🔔 Mes alertes d'achat</h1>

<?php if ($message): ?><p style="color:green;"><strong><?= $message ?></strong></p><?php endif; ?>

<form method="POST">
    <label>Mot-clé :</label><br>
    <input type="text" name="mot_cle"><br><br>

    <label>Catégorie (facultatif) :</label><br>
    <input type="text" name="categorie"><br><br>

    <label>Type de vente :</label><br>
    <select name="type_vente">
        <option value="">-- Tous types --</option>
        <option value="achat_immediat">Achat immédiat</option>
        <option value="negociation">Négociation</option>
        <option value="enchere">Enchère</option>
    </select><br><br>

    <button type="submit">Ajouter l'alerte</button>
</form>

<h2>📋 Alertes enregistrées</h2>
<ul>
    <?php foreach ($alertes as $a): ?>
        <li>
            🔍 <?= htmlspecialchars($a['mot_cle']) ?> -
            <?= $a['categorie'] ? htmlspecialchars($a['categorie']) : 'Toutes catégories' ?> -
            <?= $a['type_vente'] ?: 'Tous types' ?>
        </li>
    <?php endforeach; ?>
</ul>

<p><a href="index.php">Retour à l'accueil</a></p>
</body>
</html>
