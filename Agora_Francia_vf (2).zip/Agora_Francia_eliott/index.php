<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>
<div id="bannerCarousel" class="carousel slide banner-carousel position-relative" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php
        // Exemple d'annonces bannières (images + texte + lien)
        $banners = [
            [
                'img' => 'assets/img/banniere1.jpg',
                'text' => 'Événement spécial pikachu',
                'link' => 'produits.php?promo=charizard-vmax'
            ],
            [
                'img' =>  'assets/img/banniere2.png',
                'text' => 'Offre Limitée: bundle 151',
                'link' => 'produits.php?promo=raichu-gx'
            ],
            [
                'img' =>  'assets/img/banniere3.webp',
                'text' => 'Super Promo fable nebuleuse',
                'link' => 'produits.php?promo=mewtwo-mew-gx'
            ],
            [
                'img' =>  'assets/img/banniere4.webp',
                'text' => 'Offre: Evolution Prismatique',
                'link' => 'evenements.php#sobble-v'
            ]
        ];
        foreach ($banners as $i => $banner): ?>
            <div class="carousel-item <?= $i === 0 ? 'active' : '' ?> position-relative">
                <img src="<?= htmlspecialchars($banner['img']) ?>" alt="<?= htmlspecialchars($banner['text']) ?>" />
                <a href="<?= htmlspecialchars($banner['link']) ?>" class="btn btn-overlay"><?= htmlspecialchars($banner['text']) ?></a>
            </div>
        <?php endforeach; ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon carousel-arrow" aria-hidden="true"></span>
        <span class="visually-hidden">Précédent</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon carousel-arrow" aria-hidden="true"></span>
        <span class="visually-hidden">Suivant</span>
    </button>

    <div class="carousel-indicators mt-3">
        <?php foreach ($banners as $i => $_): ?>
            <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="<?= $i ?>" class="<?= $i === 0 ? 'active' : '' ?>" aria-current="<?= $i === 0 ? 'true' : 'false' ?>" aria-label="Slide <?= $i+1 ?>"></button>
        <?php endforeach; ?>
    </div>
</div>

    <h2 class="tendances-title">Tendances</h2>
<div class="tendances">

    <div>
        <h3>Best Sellers</h3>
        <div class="product-list">
            <?php
            $bestSellers = [
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SM10/SM10_EN_1.png', 'name'=>'Mewtwo & Mew GX', 'price'=>'89€'],
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SWSH35/SWSH35_EN_52.png', 'name'=>'Sobble V', 'price'=>'60€'],
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SM5/SM5_EN_74.png', 'name'=>'Eevee VMAX', 'price'=>'120€'],
            ];
            foreach ($bestSellers as $product): ?>
                <div class="product-card">
                    <img src="<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" />
                    <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                    <div class="product-price"><?= htmlspecialchars($product['price']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div>
        <h3>Meilleures Offres</h3>
        <div class="product-list">
            <?php
            $bestOffers = [
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SWSH45/SWSH45_EN_50.png', 'name'=>'Charizard VMAX', 'price'=>'199€'],
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SM3/SM3_EN_57.png', 'name'=>'Raichu GX', 'price'=>'75€'],
                ['img'=>'https://assets.pokemon.com/assets/cms2/img/cards/web/SM10/SM10_EN_1.png', 'name'=>'Mewtwo & Mew GX', 'price'=>'89€'],
            ];
            foreach ($bestOffers as $offer): ?>
                <div class="product-card">
                    <img src="<?= htmlspecialchars($offer['img']) ?>" alt="<?= htmlspecialchars($offer['name']) ?>" />
                    <div class="product-name"><?= htmlspecialchars($offer['name']) ?></div>
                    <div class="product-price"><?= htmlspecialchars($offer['price']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>
<div>
    <!-- EXPANSIONS -->
    <section class="expansions container-fluid px-4">
        <h2 class="section-title text-start my-4">Expansions</h2>

        <div class="row g-3">
            <!-- Colonne gauche -->
            <div class="col-12 col-lg-6">
                <div class="expansion-card">
                    <img src="assets/img/rivalite.png" alt="Rivalité Destinée">
                    <div class="expansion-overlay">
                        <div class="expansion-content">
                            <h3 class="expansion-name">Rivalité Destinée</h3>
                            <a href="produits.php?promo=rivalite-destinee" class="btn btn-primary">Voir les produits</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Colonne droite en deux parties -->
            <div class="col-12 col-lg-6 d-flex flex-column">
                <div class="expansion-card flex-fill mb-3">
                    <img src="assets/img/aventure.png" alt="Aventure Ensemble">
                    <div class="expansion-overlay">
                        <div class="expansion-content">
                            <h3 class="expansion-name">Aventure Ensemble</h3>
                            <a href="produits.php?promo=aventure-ensemble" class="btn btn-primary">Voir les produits</a>
                        </div>
                    </div>
                </div>

                <div class="expansion-card flex-fill">
                    <img src="assets/img/prisme.png" alt="Évolutions Prismatiques">
                    <div class="expansion-overlay">
                        <div class="expansion-content">
                            <h3 class="expansion-name">Évolutions Prismatiques</h3>
                            <a href="produits.php?promo=evolutions-prismatiques" class="btn btn-primary">Voir les produits</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


</div>
<div>
    <!-- Section Tutoriels - Inspiration Cardmarket -->
    <section class="how-to-use">
        <h2 class="section-title"><i class="fas fa-info-circle"></i> Comment utiliser PokéFrancia</h2>
        <p class="section-description">Découvrez comment acheter et vendre des cartes Pokémon facilement sur notre plateforme.</p>
        <div class="how-to-grid">
            <div class="how-to-box">
                <video controls poster="assets/img/how-to-buy-thumb.jpg">
                    <source src="assets/video/how-to-buy.mp4" type="video/mp4">
                    Votre navigateur ne supporte pas la lecture vidéo.
                </video>
                <h3>How to Buy</h3>
            </div>
            <div class="how-to-box">
                <video controls poster="assets/img/how-to-sell-thumb.jpg">
                    <source src="assets/video/how-to-sell.mp4" type="video/mp4">
                    Votre navigateur ne supporte pas la lecture vidéo.
                </video>
                <h3>How to Sell</h3>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>
