<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'client') {
    header('Location: login.php');
    exit;
}

$id_client = $_SESSION['user_id'];
$id_produit = $_GET['id'] ?? null;

if (!$id_produit) {
    echo "Aucun produit spécifié.";
    exit;
}

// Vérifier que le produit existe et est encore marqué disponible (optionnel)
$stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ? AND statut = 'disponible'");
$stmt->execute([$id_produit]);
$produit = $stmt->fetch();


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Achat confirmé</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h1>Merci pour votre achat !</h1>
<p>Votre commande est validée.</p>
<a href="index.php">← Accueil</a>
</body>
</html>
