<?php include 'verifier_encheres.php'; ?>

<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id_admin = $_SESSION['user_id'];
$message  = "";

/* ───── Ajout produit ───── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajout_produit'])) {
    if (isset($_POST['nom'], $_POST['prix'], $_POST['type_vente'], $_FILES['image'])) {
        $nom        = $_POST['nom'];
        $prix       = (float)$_POST['prix'];
        $type_vente = $_POST['type_vente'];
        $description= $_POST['description'] ?? '';

        $image_path = null;
        if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!file_exists($upload_dir)) mkdir($upload_dir);
            $image_path = $upload_dir . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], $image_path);
        }

        $stmt = $pdo->prepare("
            INSERT INTO produits (id_vendeur, nom, prix, type_vente, description, image, statut)
            VALUES (?, ?, ?, ?, ?, ?, 'disponible')
        ");
        $stmt->execute([$id_admin, $nom, $prix, $type_vente, $description, $image_path]);
        $message = "✅ Produit ajouté avec succès.";
    }
}

/* ───── Ajout vendeur ───── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter_vendeur'])) {
    $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("
        INSERT INTO utilisateurs
        (nom, prenom, email, mot_de_passe, type_utilisateur, adresse1, adresse2, ville, code_postal, pays, telephone)
        VALUES (?, ?, ?, ?, 'vendeur', ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_POST['nom'], $_POST['prenom'], $_POST['email'], $mot_de_passe,
        $_POST['adresse1'] ?? '', $_POST['adresse2'] ?? '', $_POST['ville'] ?? '',
        $_POST['code_postal'] ?? '', $_POST['pays'] ?? '', $_POST['telephone'] ?? ''
    ]);
    $message = "✅ Vendeur ajouté avec succès.";
}

/* ───── Suppression vendeur ───── */
if (isset($_GET['supprimer'])) {
    $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id = ? AND type_utilisateur = 'vendeur'");
    $stmt->execute([$_GET['supprimer']]);
    $message = "✅ Vendeur supprimé.";
}

/* ───── Récupérations ───── */
$produits = $pdo->prepare("SELECT * FROM produits WHERE id_vendeur = ?"); $produits->execute([$id_admin]); $produits = $produits->fetchAll();
$vendeurs = $pdo->query("SELECT * FROM utilisateurs WHERE type_utilisateur = 'vendeur'")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard admin – PokéFrancia</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>


<main style="max-width:1100px;margin:0 auto 60px;padding:0 20px;">

    <?php if ($message): ?>
        <p class="info-card fade-card" style="background:#2f3448;color:#aef2c5;text-align:center;">
            <?= $message ?>
        </p>
    <?php endif; ?>

    <!-- ─── Produits ─── -->
    <section class="info-card fade-card">
        <h2>📦 Vos produits en vente</h2>
        <table class="styled-table">
            <thead><tr>
                <th>Nom</th><th>Prix (€)</th><th>Type</th><th>Statut</th><th>Actions</th>
            </tr></thead>
            <tbody>
            <?php foreach ($produits as $p): ?>
            <tr>
                <td><?= htmlspecialchars($p['nom']) ?></td>
                <td><?= number_format($p['prix'],2,',',' ') ?></td>
                <td><?= ucfirst($p['type_vente']) ?></td>
                <td><?= ucfirst($p['statut']) ?></td>
                <td>
                    <a href="detail_produit.php?id=<?= $p['id'] ?>">🗒️ détails</a>
                    <?php if ($p['type_vente']==='negociation'): ?>
                        | <a href="detail_produit.php?id=<?= $p['id'] ?>">💬 négo</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>

    <!-- ─── Ajout produit ─── -->
    <section class="info-card fade-card">
        <h2>➕ Ajouter un produit</h2>
        <form class="dashboard-form" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="ajout_produit" value="1">
            <label>Nom <input name="nom" required></label>
            <label>Prix (€) <input type="number" step="0.01" name="prix" required></label>
            <label>Type de vente
                <select name="type_vente" required>
                    <option value="achat_immediat">Achat immédiat</option>
                    <option value="negociation">Négociation</option>
                    <option value="enchere">Enchère</option>
                </select>
            </label>
            <label style="grid-column:1/-1;">Description
                <textarea name="description" rows="3"></textarea>
            </label>
            <label>Image <input type="file" name="image" accept="image/*" required></label>
            <button class="btn-primary" type="submit">Ajouter le produit</button>
        </form>
    </section>

    <!-- ─── Ajout vendeur ─── -->
    <section class="info-card fade-card">
        <h2>👥 Ajouter un vendeur</h2>
        <form class="dashboard-form" method="POST">
            <input type="hidden" name="ajouter_vendeur" value="1">
            <label>Nom <input name="nom" required></label>
            <label>Prénom <input name="prenom" required></label>
            <label>Email <input type="email" name="email" required></label>
            <label>Mot de passe <input type="password" name="mot_de_passe" required></label>
            <label>Adresse ligne 1 <input name="adresse1"></label>
            <label>Adresse ligne 2 <input name="adresse2"></label>
            <label>Ville <input name="ville"></label>
            <label>Code postal <input name="code_postal"></label>
            <label>Pays <input name="pays"></label>
            <label>Téléphone <input name="telephone"></label>
            <button class="btn-primary" type="submit">Ajouter le vendeur</button>
        </form>
    </section>

    <!-- ─── Liste vendeurs ─── -->
    <section class="info-card fade-card">
        <h2>📋 Vendeurs</h2>
        <table class="styled-table">
            <thead><tr>
                <th>ID</th><th>Nom</th><th>Email</th><th>Adresse</th><th>Ville</th>
                <th>CP</th><th>Pays</th><th>Tél.</th><th>Action</th>
            </tr></thead>
            <tbody>
            <?php foreach ($vendeurs as $v): ?>
            <tr>
                <td><?= $v['id'] ?></td>
                <td><?= htmlspecialchars($v['prenom'].' '.$v['nom']) ?></td>
                <td><?= htmlspecialchars($v['email']) ?></td>
                <td><?= htmlspecialchars(trim($v['adresse1'].' '.$v['adresse2'])) ?></td>
                <td><?= htmlspecialchars($v['ville']) ?></td>
                <td><?= htmlspecialchars($v['code_postal']) ?></td>
                <td><?= htmlspecialchars($v['pays']) ?></td>
                <td><?= htmlspecialchars($v['telephone']) ?></td>
                <td><a href="?supprimer=<?= $v['id'] ?>" onclick="return confirm('Supprimer ce vendeur ?')">❌</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
