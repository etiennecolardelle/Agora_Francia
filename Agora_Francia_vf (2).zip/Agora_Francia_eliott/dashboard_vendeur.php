<?php include 'verifier_encheres.php'; ?>

<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'vendeur') {
    header("Location: login.php");
    exit;
}

$id_vendeur = $_SESSION['user_id'];

// Traitement ajout de produit
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom'], $_POST['prix'], $_POST['type_vente'], $_FILES['image'])) {
    $nom = $_POST['nom'];
    $prix = floatval($_POST['prix']);
    $type_vente = $_POST['type_vente'];
    $description = $_POST['description'] ?? '';

    $image_path = null;
    if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        if (!file_exists($upload_dir)) mkdir($upload_dir, 0755, true);
        $image_path = $upload_dir . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);
    }

    $stmt = $pdo->prepare("INSERT INTO produits (id_vendeur, nom, prix, type_vente, description, image, statut) VALUES (?, ?, ?, ?, ?, ?, 'disponible')");
    $stmt->execute([$id_vendeur, $nom, $prix, $type_vente, $description, $image_path]);
    $message = "✅ Produit ajouté avec succès.";
}

// Récupérer tous les produits du vendeur
$stmt = $pdo->prepare("SELECT * FROM produits WHERE id_vendeur = ?");
$stmt->execute([$id_vendeur]);
$produits = $stmt->fetchAll();
?>

<!-- HEADER + NAVBAR communs -->
<!-- ───── HEADER + NAVBAR communs ───── -->
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>

<style>
    main.vendeur-dashboard {
        max-width: 1000px;
        margin: 40px auto 80px;
        padding: 0 20px;
        font-family: 'Poppins', sans-serif;
        color: #eee;
    }
    h1.dashboard-title {
        font-size: 2.8rem;
        text-align: center;
        margin-bottom: 30px;
        background: linear-gradient(90deg, #ff416c, #7a64b8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        user-select: none;
    }
    h2.section-title {
        color: #ffb2c4;
        margin-bottom: 20px;
        font-size: 1.6rem;
        border-bottom: 2px solid #7a64b8;
        padding-bottom: 6px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background: #3b3f63;
        box-shadow: 0 0 18px rgba(122, 100, 184, 0.35);
        border-radius: 12px;
        overflow: hidden;
        color: #fff;
        margin-bottom: 40px;
    }
    table th, table td {
        padding: 14px 18px;
        text-align: left;
    }
    table th {
        background: #6b63a7;
    }
    table tr:nth-child(even) {
        background: #484b72;
    }
    table a {
        color: #ff9bba;
        font-weight: 600;
        text-decoration: none;
        transition: color 0.2s ease;
    }
    table a:hover {
        color: #ff416c;
        text-decoration: underline;
    }
    form {
        background: #3b3f63;
        padding: 20px 25px;
        border-radius: 14px;
        box-shadow: 0 0 18px rgba(122, 100, 184, 0.35);
        color: #eee;
        max-width: 600px;
        margin: 0 auto 50px;
    }
    form label {
        display: block;
        margin-top: 14px;
        font-weight: 600;
        color: #ffb2c4;
    }
    form input[type="text"],
    form input[type="number"],
    form select,
    form textarea,
    form input[type="file"] {
        width: 100%;
        padding: 8px 10px;
        margin-top: 6px;
        border-radius: 8px;
        border: none;
        outline: none;
        font-size: 1rem;
        background: #55597b;
        color: #eee;
        box-sizing: border-box;
    }
    form textarea {
        resize: vertical;
        min-height: 80px;
    }
    form button {
        margin-top: 20px;
        background: linear-gradient(90deg, #ff416c, #7a64b8);
        border: none;
        color: white;
        padding: 12px 24px;
        font-size: 1.1rem;
        font-weight: 700;
        border-radius: 12px;
        cursor: pointer;
        transition: background 0.3s ease;
    }
    form button:hover {
        background: linear-gradient(90deg, #7a64b8, #ff416c);
    }
    .message {
        max-width: 600px;
        margin: 0 auto 30px;
        color: #7ee27e;
        font-weight: 700;
        text-align: center;
        font-size: 1.2rem;
    }
    .links-bottom {
        text-align: center;
        margin-top: 20px;
        font-weight: 600;
        color: #ff9bba;
    }
    .links-bottom a {
        color: #ff9bba;
        margin: 0 10px;
        text-decoration: none;
        transition: color 0.2s ease;
    }
    .links-bottom a:hover {
        color: #ff416c;
        text-decoration: underline;
    }
</style>

<main class="vendeur-dashboard">
    <h1 class="dashboard-title">👨‍💼 Tableau de bord vendeur</h1>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <section>
        <h2 class="section-title">📦 Vos produits en vente</h2>
        <?php if (count($produits) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prix (€)</th>
                    <th>Type de vente</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produits as $produit): ?>
                    <tr>
                        <td><?= htmlspecialchars($produit['nom']) ?></td>
                        <td><?= number_format($produit['prix'], 2, ',', ' ') ?> €</td>
                        <td><?= htmlspecialchars($produit['type_vente']) ?></td>
                        <td><?= htmlspecialchars($produit['statut']) ?></td>
                        <td>
                            <a href="detail_produit.php?id=<?= $produit['id'] ?>">🗒️ Détails</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p>Aucun produit en vente pour le moment.</p>
        <?php endif; ?>
    </section>

    <section>
        <h2 class="section-title">📤 Ajouter un nouveau produit</h2>
        <form method="POST" enctype="multipart/form-data" novalidate>
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>

            <label for="prix">Prix (€) :</label>
            <input type="number" step="0.01" id="prix" name="prix" required>

            <label for="type_vente">Type de vente :</label>
            <select id="type_vente" name="type_vente" required>
                <option value="achat_immediat">Achat immédiat</option>
                <option value="negociation">Négociation</option>
                <option value="enchere">Enchère</option>
            </select>

            <label for="description">Description :</label>
            <textarea id="description" name="description"></textarea>

            <label for="image">Image :</label>
            <input type="file" id="image" name="image" accept="image/*" required>

            <button type="submit">Ajouter le produit</button>
        </form>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
