document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebar");

    toggle.addEventListener("click", () => {
        sidebar.classList.toggle("show");
    });

    const audioControl = document.getElementById("audio-control");
    let muted = true;

    audioControl.addEventListener("click", () => {
        muted = !muted;
        audioControl.textContent = muted ? "🔇" : "🔊";
    });
});
