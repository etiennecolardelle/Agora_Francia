<hr />
<footer class="footer-custom text-center py-3">
    <p>© <?= date('Y') ?> PokéFrancia | Contact : contact@pokefrancia.fr</p>
</footer>

<!-- Musique de fond -->
<audio id="bg-music" src="assets/audio/pokemon_theme.mp3" loop autoplay muted></audio>


<!-- Script de gestion du son -->
<script>
    const audio = document.getElementById('bg-music');
    const control = document.getElementById('audio-control');

    control.addEventListener('click', () => {
        if (audio.muted || audio.paused) {
            audio.muted = false;
            audio.play().catch(e => console.log("Erreur lecture audio :", e));
            control.textContent = '🔊';
        } else {
            audio.pause();
            control.textContent = '🔇';
        }
    });
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
