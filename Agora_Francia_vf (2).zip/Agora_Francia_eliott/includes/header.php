<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>PokéFrancia - Accueil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        body, html {
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        .header-custom {
            background: linear-gradient(90deg, #ff99cc, #ff66cc);
            padding: 60px 0 40px;
            position: relative;
            overflow: hidden;
        }

        .header-title {
            font-family: 'Press Start 2P', cursive;
            font-size: 2rem;
            text-align: center;
            z-index: 1;
            position: relative;
            color: white;
            text-shadow: 2px 2px 0 #cc3366;
        }

        .pokemon-carousel {
            position: absolute;
            width: 200%;
            height: 64px;
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .pokemon-carousel img {
            width: 64px;
            height: 64px;
            flex-shrink: 0;
            user-select: none;
            pointer-events: none;
            filter: drop-shadow(1px 1px 2px rgba(0,0,0,0.3));
            background-color: transparent;
        }

        .left-marquee {
            top: 0;
            left: 0;
            animation: slideLeft 40s linear infinite;
        }

        .right-marquee {
            bottom: 0;
            left: -100%;
            animation: slideRight 50s linear infinite;
        }

        @keyframes slideLeft {
            0%   { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }

        @keyframes slideRight {
            0%   { transform: translateX(0); }
            100% { transform: translateX(50%); }
        }

        .marquee-wrapper {
            overflow: hidden;
            position: relative;
            height: 64px;
            width: 100%;
            background: transparent;
            z-index: 0;
        }
    </style>
</head>
<body>
<header class="header-custom">

    <div class="marquee-wrapper">
        <div class="pokemon-carousel left-marquee">
            <?php
            $sprites = [25, 150, 133, 52, 143, 29, 39, 58, 7, 1];
            for ($i = 0; $i < 2; $i++) {
                foreach ($sprites as $id) {
                    echo '<img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/' . $id . '.png" alt="Pokémon" />';
                }
            }
            ?>
        </div>
    </div>

    <h1 class="header-title">PokéFrancia</h1>

    <div class="marquee-wrapper">
        <div class="pokemon-carousel right-marquee">
            <?php
            $spritesRight = [4, 39, 94, 122, 65, 6, 26, 150, 95, 143];
            for ($i = 0; $i < 2; $i++) {
                foreach ($spritesRight as $id) {
                    echo '<img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/' . $id . '.png" alt="Pokémon" />';
                }
            }
            ?>
        </div>
    </div>

</header>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
