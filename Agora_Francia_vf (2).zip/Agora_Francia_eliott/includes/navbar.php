<?php if (session_status() === PHP_SESSION_NONE) ; ?>
<nav class="navbar navbar-expand-lg navbar-custom px-3">
    <div class="container-fluid">
        <!-- Bouton hamburger -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
                aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="hamburger-icon">
                <span></span><span></span><span></span>
            </span>
        </button>
        <!-- Menu déroulant -->
        <div class="collapse navbar-collapse mt-2 mt-lg-0" id="mainNavbar">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item mx-2"><a class="nav-link" href="index.php">Accueil</a></li>
                <li class="nav-item mx-2"><a class="nav-link" href="produits.php">Tout parcourir</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>

                    <?php if ($_SESSION['type'] === 'vendeur'): ?>
                        <li class="nav-item mx-2"><a class="nav-link" href="dashboard_vendeur.php">Espace vendeur</a></li>
                    <?php elseif ($_SESSION['type'] === 'admin'): ?>
                        <li class="nav-item mx-2"><a class="nav-link" href="dashboard_admin.php">Admin</a></li>
                    <?php elseif ($_SESSION['type'] === 'client'): ?>
                        <li class="nav-item mx-2"><a class="nav-link" href="dashboard_client.php">Mes achats</a></li>
                    <?php endif; ?>

                    <li class="nav-item mx-2">
                        <a class="nav-link" href="panier.php">Panier
                            <?php
                            $count = isset($_SESSION['panier']) ? count($_SESSION['panier']) : 0;
                            if ($count > 0) {
                                echo " ($count)";
                            }
                            ?>
                        </a>
                    </li>
                    <li class="nav-item mx-2"><a class="nav-link" href="alertes.php">Alertes</a></li>
                    <li class="nav-item mx-2"><a class="nav-link" href="account.php">Compte</a></li>
                    <li class="nav-item mx-2"><a class="nav-link" href="logout.php">Déconnexion</a></li>
                <?php else: ?>
                    <li class="nav-item mx-2"><a class="nav-link" href="login.php">Connexion</a></li>
                    <li class="nav-item mx-2"><a class="nav-link" href="register.php">Inscription</a></li>
                <?php endif; ?>
                <button id="audio-control" class="btn btn-outline-light ms-auto" title="Activer/Désactiver la musique" style="font-size: 20px;">
                    🔇
                </button>
            </ul>

        </div>
    </div>
</nav>
