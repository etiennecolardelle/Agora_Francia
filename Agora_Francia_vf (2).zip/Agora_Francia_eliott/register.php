<?php
/* ─── register.php ───────────────────────────────────────────── */
require 'config/db.php';

$erreur   = '';
$message  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    /** Récupération + mini-validation **/
    $nom        = trim($_POST['nom']        ?? '');
    $prenom     = trim($_POST['prenom']     ?? '');
    $email      = trim($_POST['email']      ?? '');
    $password   = $_POST['mot_de_passe']    ?? '';
    $type       = $_POST['type_utilisateur']?? 'client';
    $adresse1   = trim($_POST['adresse1']   ?? '');
    $adresse2   = trim($_POST['adresse2']   ?? '');
    $ville      = trim($_POST['ville']      ?? '');
    $cp         = trim($_POST['code_postal']?? '');
    $pays       = trim($_POST['pays']       ?? '');
    $tel        = trim($_POST['telephone']  ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreur = "Adresse e-mail invalide.";
    }

    if (!$erreur) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO utilisateurs
                (nom, prenom, email, mot_de_passe, type_utilisateur,
                 adresse1, adresse2, ville, code_postal, pays, telephone)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        $pdo->prepare($sql)->execute([
            $nom, $prenom, $email, $hash, $type,
            $adresse1, $adresse2, $ville, $cp, $pays, $tel
        ]);

        $id_new_user = $pdo->lastInsertId();

        /* Sécurité : rattache les paiements en attente déjà existants */
        $q = $pdo->prepare("SELECT id_produit
                            FROM negociations
                            WHERE id_client = ? AND etat = 'acceptee'");
        $q->execute([$id_new_user]);
        foreach ($q as $n) {
            $pdo->prepare("
                INSERT INTO paiements_en_attente (id_client,id_produit)
                VALUES (?,?)
                ON DUPLICATE KEY UPDATE id_client = id_client
            ")->execute([$id_new_user, $n['id_produit']]);
        }

        $message = "✅ Compte créé avec succès ! <a href='login.php'>Connectez-vous</a>";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription – PokéFrancia</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />s
</head>
<style>
    .section-title {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 2rem;

            text-shadow: 1px 1px 0 #fff;
        }
</style>
<body>
<!-- Header & Navbar (même DA) -->
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>
<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>

<main style="max-width:950px;margin:40px auto 80px;padding:0 20px;">
     <div class="container">
     <h1 class="section-title">Inscription</h1>

    <?php if ($erreur): ?>
        <div class="error-message" style="max-width:600px;margin:0 auto;">
            <?= htmlspecialchars($erreur) ?>
        </div>
    <?php elseif ($message): ?>
        <p class="message" style="max-width:600px;margin:0 auto;">
            <?= $message ?>
        </p>
    <?php endif; ?>

    <!-- Formulaire stylé avec la DA existante -->
    <form method="POST" class="dashboard-form fade-card" style="margin-top:30px;">
        <!-- Identité -->
        <label>Nom
            <input name="nom" value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
        </label>
        <label>Prénom
            <input name="prenom" value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
        </label>

        <!-- Coordonnées -->
        <label>Email
            <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </label>
        <label>Mot de passe
            <input type="password" name="mot_de_passe" required>
        </label>

        <label>Adresse ligne 1
            <input name="adresse1" value="<?= htmlspecialchars($_POST['adresse1'] ?? '') ?>" required>
        </label>
        <label>Adresse ligne 2
            <input name="adresse2" value="<?= htmlspecialchars($_POST['adresse2'] ?? '') ?>">
        </label>
        <label>Ville
            <input name="ville" value="<?= htmlspecialchars($_POST['ville'] ?? '') ?>" required>
        </label>
        <label>Code postal
            <input name="code_postal" value="<?= htmlspecialchars($_POST['code_postal'] ?? '') ?>" required>
        </label>
        <label>Pays
            <input name="pays" value="<?= htmlspecialchars($_POST['pays'] ?? '') ?>" required>
        </label>
        <label>Téléphone
            <input name="telephone" value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>" required>
        </label>
        <?= ($_POST['type_utilisateur'] ?? '')==='client'?>
        <div style="text-align:center;margin-top:25px;">
            <button type="submit" class="btn-primary">Créer mon compte</button>
        </div>
    </form>


    <div class="links-bottom">
        Vous avez déjà un compte ? <a href="login.php">Connexion</a>
    </div>
    </div>

</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
