<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
</head>
<body>
    <div class="overlay">
            <div class="pokeball-close"></div>
    </div>
    <script>  setTimeout(() => { <?php echo 'window.location.href = "index.php";'?> }, 1800); </script>
</body>