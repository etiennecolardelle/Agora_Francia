<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

$message = '';

// Ajouter un produit
if (isset($_GET['ajouter'])) {
    $id_produit = $_GET['ajouter'];
    if (!in_array($id_produit, $_SESSION['panier'])) {
        $_SESSION['panier'][] = $id_produit;
        $message = "Produit ajouté au panier.";
    }
}

// Supprimer un produit
if (isset($_GET['supprimer'])) {
    $id_produit = $_GET['supprimer'];
    $_SESSION['panier'] = array_diff($_SESSION['panier'], [$id_produit]);
    $message = "Produit retiré du panier.";
}

$produits = [];
$total = 0;

if (!empty($_SESSION['panier'])) {
    $placeholders = implode(',', array_fill(0, count($_SESSION['panier']), '?'));
    $stmt = $pdo->prepare("SELECT * FROM produits WHERE id IN ($placeholders)");
    $stmt->execute($_SESSION['panier']);
    $produits = $stmt->fetchAll();

    foreach ($produits as $produit) {
        $total += $produit['prix'];
    }
}

function traductionTypeVente(string $type): string {
    return match ($type) {
        'achat_immediat' => 'Achat immédiat',
        'negociation'    => 'Négociation',
        'enchere'        => 'Enchère',
        default          => 'Inconnu',
    };
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon panier - PokéFrancia</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <style>
        body {
            background: linear-gradient(135deg, #ff416c, #7a64b8);
            color: white;
            font-family: 'Segoe UI', sans-serif;
        }
        main {
            max-width: 1000px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }
        h1 {
            text-align: center;
            margin-bottom: 2rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            overflow: hidden;
        }
        thead th {
            background: #7a64b8;
            padding: 1rem;
            text-align: left;
            text-transform: uppercase;
        }
        tbody td {
            padding: 1rem;
            vertical-align: middle;
        }
        tbody tr:nth-child(even) {
            background: rgba(255,255,255,0.05);
        }
        img.card-image {
            height: 80px;
            object-fit: contain;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 5px #0005;
        }
        .total {
            text-align: right;
            font-weight: bold;
            font-size: 1.4rem;
            margin-top: 2rem;
        }
        .actions a {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            background: #444b7a;
            color: white;
            text-decoration: none;
            margin-right: 0.5rem;
        }
        .actions a:hover {
            background: #5c57a0;
        }
    </style>
</head>
<body>
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>
<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>
<main>
    <h1>Mon panier</h1>
    <?php if ($message): ?>
        <div class="message" style="text-align:center; margin-bottom: 1rem; background:#28a745; padding:10px; border-radius:10px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <?php if (empty($produits)): ?>
        <p style="text-align:center; font-size:1.2rem;">Votre panier est vide.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Image</th>
                <th>Nom</th>
                <th>Prix</th>
                <th>Type</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($produits as $produit): ?>
                <tr>
                    <td>
                        <?php if (!empty($produit['image'])): ?>
                            <img src="<?= htmlspecialchars($produit['image']) ?>" alt="Image produit" class="card-image">
                        <?php else: ?>
                            <span>Image non dispo</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($produit['nom']) ?></td>
                    <td><?= number_format($produit['prix'], 2, ',', ' ') ?> €</td>
                    <td><?= traductionTypeVente($produit['type_vente']) ?></td>
                    <td class="actions">
                        <a href="?supprimer=<?= $produit['id'] ?>">❌ Retirer</a>
                        <?php if ($produit['type_vente'] === 'achat_immediat'): ?>
                            <a href="acheter.php?id=<?= $produit['id'] ?>">💳 Acheter</a>
                        <?php elseif ($produit['type_vente'] === 'negociation'): ?>
                            <a href="negocier.php?id=<?= $produit['id'] ?>">🤝 Négocier</a>
                        <?php elseif ($produit['type_vente'] === 'enchere'): ?>
                            <a href="encherir.php?id=<?= $produit['id'] ?>">📈 Enchérir</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="total">
            Total : <?= number_format($total, 2, ',', ' ') ?> €
        </div>
    <?php endif; ?>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
