<?php include 'verifier_encheres.php'; ?>

<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'client') {
    header("Location: login.php");
    exit;
}

$id_client = $_SESSION['user_id'];

/* ─── Récupération des données ─── */
$panier = $pdo->prepare("
    SELECT p.* FROM panier pa
    JOIN produits p ON p.id = pa.id_produit
    WHERE pa.id_client = ?
"); $panier->execute([$id_client]);
$panier = $panier->fetchAll();

$en_cours = $pdo->prepare("
    SELECT DISTINCT p.* FROM produits p
    LEFT JOIN negociations n ON n.id_produit = p.id
    LEFT JOIN encheres e  ON e.id_produit = p.id
    WHERE (n.id_client = :id OR e.id_client = :id) AND p.statut <> 'vendu'
"); $en_cours->execute(['id'=>$id_client]); $en_cours = $en_cours->fetchAll();

$historique = $pdo->prepare("
    SELECT p.* FROM produits p
    JOIN commandes c ON c.id_produit = p.id
    WHERE c.id_client = ?
"); $historique->execute([$id_client]); $historique = $historique->fetchAll();

$attente_paiement = $pdo->prepare("
    SELECT p.* FROM paiements_en_attente pa
    JOIN produits p ON p.id = pa.id_produit
    WHERE pa.id_client = ? AND pa.paye = 0
"); $attente_paiement->execute([$id_client]); $attente_paiement = $attente_paiement->fetchAll();
?>

<!-- ───── HEADER + NAVBAR communs ───── -->
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>

<!-- ───── Style spécifique à cette page (dans le <body>, cela reste valide) ───── -->
<style>
    /* surcharges légères respectant style.css (Poppins, palette violet-rose) */
    main.client-dashboard{
        max-width:1000px;
        margin:0 auto 60px;
        padding:0 20px;
    }
    h1.client-title{
        text-align:center;
        font-size:2.6rem;
        margin:40px 0 10px;
        background:linear-gradient(90deg,#ff416c,#7a64b8);
        -webkit-background-clip:text;
        -webkit-text-fill-color:transparent;
        user-select:none;
    }
    h2.section-title{
        color:#ffb2c4;
        margin-top:35px;
        font-size:1.6rem;
    }
    ul.card-list{
        list-style:none;
        padding-left:0;
        margin-top:15px;
    }
    ul.card-list li{
        background:#3b3f63;
        border-radius:16px;
        padding:18px 22px;
        margin-bottom:14px;
        box-shadow:0 0 18px rgba(122,100,184,.35);
        display:flex;
        justify-content:space-between;
        align-items:center;
        transition:transform .2s ease;
    }
    ul.card-list li:hover{transform:translateY(-4px);}
    ul.card-list li a{
        color:#ff9bba;
        font-weight:600;
        text-decoration:none;
    }
    ul.card-list li a:hover{text-decoration:underline;}
    .links-bottom{
        text-align:center;
        margin-top:50px;
        font-weight:600;
    }
    .links-bottom a{
        color:#ff9bba;
        margin:0 10px;
        text-decoration:none;
    }
    .links-bottom a:hover{text-decoration:underline;}
</style>

<!-- ───── Contenu ───── -->
<main class="client-dashboard">

    <h1 class="client-title">🎒 Tableau de bord dresseur</h1>

    <!-- Achats en cours -->
    <h2 class="section-title">🕓 Achats en cours</h2>
    <ul class="card-list">
        <?php foreach ($en_cours as $p): ?>
            <li>
                <?= htmlspecialchars($p['nom']) ?> – <?= $p['type_vente'] ?>
                <a href="detail_produit.php?id=<?= $p['id'] ?>">✨ Détails</a>
            </li>
        <?php endforeach; ?>
        <?php if (empty($en_cours)) echo '<p>Aucun achat en cours.</p>'; ?>
    </ul>

    <!-- Paiement en attente -->
    <h2 class="section-title">💳 Produits à payer</h2>
    <ul class="card-list">
        <?php foreach ($attente_paiement as $p): ?>
            <li>
                <?= htmlspecialchars($p['nom']) ?> – <?= number_format($p['prix'],2,',',' ') ?> €
                <a href="paiement.php?produit=<?= $p['id'] ?>">💳 Payer</a>
            </li>
        <?php endforeach; ?>
        <?php if (empty($attente_paiement)) echo '<p>Aucun paiement en attente.</p>'; ?>
    </ul>

    <!-- Historique -->
    <h2 class="section-title">📜 Historique de vos achats</h2>
    <ul class="card-list">
        <?php foreach ($historique as $p): ?>
            <li>
                <?= htmlspecialchars($p['nom']) ?> – <?= number_format($p['prix'],2,',',' ') ?> €
                <a href="detail_produit.php?id=<?= $p['id'] ?>">👁 Voir</a>
            </li>
        <?php endforeach; ?>
        <?php if (empty($historique)) echo '<p>Aucun achat finalisé.</p>'; ?>
    </ul>
</main>

<?php include 'includes/footer.php'; ?>
