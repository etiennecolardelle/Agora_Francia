CREATE DATABASE agora_francia;
USE agora_francia;

-- Table des utilisateurs
CREATE TABLE utilisateurs (
                              id INT AUTO_INCREMENT PRIMARY KEY,
                              nom VARCHAR(100),
                              prenom VARCHAR(100),
                              email VARCHAR(150) UNIQUE,
                              mot_de_passe VARCHAR(255),
                              type_utilisateur ENUM('admin', 'vendeur', 'client') NOT NULL,
                              adresse1 VARCHAR(255),
                              adresse2 VARCHAR(255),
                              ville VARCHAR(100),
                              code_postal VARCHAR(20),
                              pays VARCHAR(100),
                              telephone VARCHAR(20),
                              date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des produits
CREATE TABLE produits (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          id_vendeur INT,
                          nom VARCHAR(150),
                          description TEXT,
                          prix DECIMAL(10,2),
                          categorie ENUM('meubles', 'accessoires', 'scolaire'),
                          type_vente ENUM('achat_immediat', 'negociation', 'enchere'),
                          statut ENUM('disponible', 'vendu') DEFAULT 'disponible',
                          image VARCHAR(255),
                          date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                          FOREIGN KEY (id_vendeur) REFERENCES utilisateurs(id),
                          fin_enchere DATETIME DEFAULT NULL
);


CREATE TABLE panier (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        id_client INT,
                        id_produit INT,
                        date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (id_client) REFERENCES utilisateurs(id),
                        FOREIGN KEY (id_produit) REFERENCES produits(id)
);

CREATE TABLE encheres (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          id_produit INT,
                          id_client INT,
                          prix_max DECIMAL(10,2),
                          date_enchere TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                          FOREIGN KEY (id_produit) REFERENCES produits(id),
                          FOREIGN KEY (id_client) REFERENCES utilisateurs(id)
);


-- 1. Table des négociations (1 par client-produit)
CREATE TABLE negociations (
                              id INT AUTO_INCREMENT PRIMARY KEY,
                              id_produit INT,
                              id_client INT,
                              etat ENUM('en_cours', 'terminee', 'acceptee', 'refusee') DEFAULT 'en_cours',
                              FOREIGN KEY (id_produit) REFERENCES produits(id),
                              FOREIGN KEY (id_client) REFERENCES utilisateurs(id)
);

-- 2. Table des échanges
CREATE TABLE negociation_messages (
                                      id INT AUTO_INCREMENT PRIMARY KEY,
                                      id_negociation INT,
                                      auteur ENUM('client', 'vendeur'),
                                      prix DECIMAL(10,2),
                                      date_echange TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                      FOREIGN KEY (id_negociation) REFERENCES negociations(id)
);

CREATE TABLE alertes (
                         id INT AUTO_INCREMENT PRIMARY KEY,
                         id_client INT NOT NULL,
                         mot_cle VARCHAR(255),
                         categorie VARCHAR(255),
                         type_vente ENUM('achat_immediat', 'negociation', 'enchere'),
                         date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                         FOREIGN KEY (id_client) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

CREATE TABLE cartes_bancaires (
                                  id INT AUTO_INCREMENT PRIMARY KEY,
                                  type_carte ENUM('Visa', 'MasterCard', 'American Express', 'PayPal'),
                                  numero VARCHAR(20) NOT NULL,
                                  nom_carte VARCHAR(100) NOT NULL,
                                  date_expiration DATE NOT NULL,
                                  code_securite VARCHAR(4) NOT NULL
);

INSERT INTO cartes_bancaires (type_carte, numero, nom_carte, date_expiration, code_securite)
VALUES ('Visa', '4111111111111111', 'Eliott PERROTIN', '2026-12-31', '123');

CREATE TABLE paiements_en_attente (
                                      id INT AUTO_INCREMENT PRIMARY KEY,
                                      id_client INT NOT NULL,
                                      id_produit INT NOT NULL,
                                      paye TINYINT DEFAULT 0,
                                      date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE commandes (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           id_client INT NOT NULL,
                           id_produit INT NOT NULL,
                           date_commande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                           FOREIGN KEY (id_client) REFERENCES utilisateurs(id) ON DELETE CASCADE,
                           FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE CASCADE
);