<?php
$host = 'localhost';
$db   = 'agora_francia';
$user = 'root'; // ou ton identifiant MySQL
$pass = '';     // ou ton mot de passe MySQL
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (\PDOException $e) {
    echo "Erreur de connexion à la BDD : " . $e->getMessage();
    exit;
}
?>
