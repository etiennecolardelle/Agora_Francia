<?php
// verifier_encheres.php : Script à appeler régulièrement (ex. via cron) pour clore les enchères expirées
require 'config/db.php';

$now = date('Y-m-d H:i:s');

// Sélectionner les produits en enchère expirés, non encore vendus
$stmt = $pdo->prepare("
    SELECT p.id, p.nom, p.fin_enchere, MAX(e.prix_max) AS prix_gagnant, e.id_client
    FROM produits p
    JOIN encheres e ON e.id_produit = p.id
    WHERE p.type_vente = 'enchere' AND p.statut != 'vendu' AND p.fin_enchere IS NOT NULL AND p.fin_enchere < ?
    GROUP BY p.id
");
$stmt->execute([$now]);
$produits = $stmt->fetchAll();

foreach ($produits as $p) {
    if ($p['id_client']) {
        // Marquer comme vendu
        $pdo->prepare("UPDATE produits SET statut = 'vendu' WHERE id = ?")
            ->execute([$p['id']]);

        // Enregistrer comme à payer
        $pdo->prepare("INSERT INTO paiements_en_attente (id_client, id_produit) VALUES (?, ?)")
            ->execute([$p['id_client'], $p['id']]);
    }
}