<?php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['user_id'];
$type    = $_SESSION['type'] ?? 'client';

/* ───────── Récupération de l’utilisateur ───────── */
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$id_user]);
$user = $stmt->fetch();

$message = '';

/* ───────── Mise à jour éventuelle ───────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'adresse1'     => $_POST['adresse1']     ?? '',
        'adresse2'     => $_POST['adresse2']     ?? '',
        'ville'        => $_POST['ville']        ?? '',
        'code_postal'  => $_POST['code_postal']  ?? '',
        'pays'         => $_POST['pays']         ?? '',
        'telephone'    => $_POST['telephone']    ?? '',
    ];
    $stmt = $pdo->prepare("
        UPDATE utilisateurs
        SET adresse1   = ?, adresse2 = ?, ville = ?, code_postal = ?,
            pays       = ?, telephone = ?
        WHERE id = ?
    ");
    $stmt->execute([...array_values($fields), $id_user]);

    $message = "✅ Informations mises à jour avec succès !";
    /* Recharger */
    $stmt->execute([$id_user]);
    $user = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon compte – PokéFrancia</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
</head>
<body>

<!-- Header + navbar déjà stylisés via tes includes -->
<div id="page-top">
    <?php include 'includes/header.php'; ?>
</div>

<div class="navbar-sticky">
    <?php include 'includes/navbar.php'; ?>
</div>

<main style="max-width:1000px;margin:0 auto 60px;padding:0 20px;">

    <?php if ($message): ?>
        <p class="info-card fade-card" style="background:#2f3448;color:#aef2c5;text-align:center;">
            <?= $message ?>
        </p>
    <?php endif; ?>

    <!-- ───── Bloc infos utilisateur ───── -->
    <section class="info-card fade-card">
        <h2>👤 Mes informations</h2>
        <ul class="info-list">
            <li><strong>Nom complet :</strong><span><?= htmlspecialchars($user['prenom'].' '.$user['nom']) ?></span></li>
            <li><strong>Email :</strong><span><?= htmlspecialchars($user['email']) ?></span></li>
            <li><strong>Rôle :</strong><span><?= htmlspecialchars($user['type_utilisateur']) ?></span></li>
            <li><strong>Inscription :</strong><span><?= htmlspecialchars($user['date_creation']) ?></span></li>
        </ul>
    </section>

    <!-- ───── Formulaire contact ───── -->
    <section class="info-card fade-card">
        <h2>🏠 Infos de contact</h2>
        <form method="POST" class="contact-form">
            <label for="adresse1">Adresse ligne 1</label>
            <input id="adresse1" name="adresse1" type="text" value="<?= htmlspecialchars($user['adresse1'] ?? '') ?>">

            <label for="adresse2">Adresse ligne 2</label>
            <input id="adresse2" name="adresse2" type="text" value="<?= htmlspecialchars($user['adresse2'] ?? '') ?>">

            <label for="ville">Ville</label>
            <input id="ville" name="ville" type="text" value="<?= htmlspecialchars($user['ville'] ?? '') ?>">

            <label for="code_postal">Code postal</label>
            <input id="code_postal" name="code_postal" type="text" value="<?= htmlspecialchars($user['code_postal'] ?? '') ?>">

            <label for="pays">Pays</label>
            <input id="pays" name="pays" type="text" value="<?= htmlspecialchars($user['pays'] ?? '') ?>">

            <label for="telephone">Téléphone</label>
            <input id="telephone" name="telephone" type="text" value="<?= htmlspecialchars($user['telephone'] ?? '') ?>">

            <button class="btn-save" type="submit">💾 Mettre à jour</button>
        </form>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
