<?php
session_start();
require 'config/db.php';

$erreur = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    // Attention au nom du champ : on gère motdepasse ou mot_de_passe avec fallback
    $mdp = $_POST['motdepasse'] ?? ($_POST['mot_de_passe'] ?? '');

    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($mdp, $user['mot_de_passe'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['type'] = $user['type_utilisateur'];

        // Charger le panier
        $_SESSION['panier'] = [];
        $stmt = $pdo->prepare("SELECT id_produit FROM panier WHERE id_client = ?");
        $stmt->execute([$user['id']]);
        foreach ($stmt->fetchAll() as $item) {
            $_SESSION['panier'][] = $item['id_produit'];
        }

        $success = true;
    } else {
        $erreur = "❌ Identifiants incorrects.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Connexion Pokémon</title>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
            font-family: 'Press Start 2P', cursive;
            background-image: url('assets/img/pokemon-bg.png'); /* <- ton image ici */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            margin: 0;
        }
    </style>
</head>
<body>

<div class="pokedex-card">
    <h2>🔐 Connexion</h2>

    <?php if (!empty($erreur)): ?>
        <div class="error-message"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <input type="email" name="email" placeholder="Email" required autofocus />
        <input type="password" name="motdepasse" placeholder="Mot de passe" required />
        <button type="submit">Se connecter</button>
    </form>

    <p><a href="register.php">📝 Créer un compte</a></p>
</div>

<?php if ($success): ?>
    <div class="overlay">
        <div class="pokeball-close"></div>
    </div>

    <script>
        // Redirection après animation (2s)
        setTimeout(() => {
            <?php
            // Redirection selon type (PHP côté client dans JS)
            if ($user['type_utilisateur'] === 'client') {
                echo 'window.location.href = "dashboard_client.php";';
            } elseif ($user['type_utilisateur'] === 'vendeur') {
                echo 'window.location.href = "dashboard_vendeur.php";';
            } else {
                echo 'window.location.href = "dashboard_admin.php";';
            }
            ?>
        }, 1800);
    </script>
<?php endif; ?>

</body>
</html>
