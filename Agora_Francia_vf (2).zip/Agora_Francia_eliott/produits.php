<?php
session_start();
require 'config/db.php';

// Récupération des produits disponibles
$stmt = $pdo->prepare("SELECT * FROM produits WHERE statut = :statut");
$stmt->execute(['statut' => 'disponible']);
$produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tri des produits par type de vente
$categories = [
    'achat_immediat' => [],
    'enchere' => [],
    'negociation' => []
];

foreach ($produits as $p) {
    $categories[$p['type_vente']][] = $p;
}

function libelleType($type) {
    return match ($type) {
        'achat_immediat' => '🛒 Achat immédiat',
        'enchere'        => '💸 Enchère',
        'negociation'    => '💬 Négociation',
        default          => 'Inconnu',
    };
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits - Agora Francia</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <style>
        body {
            font-family: sans-serif;
            background: linear-gradient(90deg, #ff416c, #7a64b8);
            color: white;
        }
        .carousel-item {
            padding: 20px 0;
        }
        .product-card {
            background-color: #444b7a;
            border-radius: 20px;
            padding: 15px;
            box-shadow: 0 0 15px #7a64b8;
            text-align: center;
            transition: transform 0.25s ease;
            cursor: pointer;
            user-select: none;
            color: white;
        }
        .product-card img {
            height: 200px;
            object-fit: contain;
            background: transparent;
            border-radius: 10px;
        }
        .prix {
            font-weight: bold;
            color: #ffe600;
        }
        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            background-color: rgba(0,0,0,0.5);
            border-radius: 50%;
        }
    </style>
</head>
<body>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container my-4">
    <h1 class="text-center">🃏 Tous les produits disponibles</h1>

    <?php foreach ($categories as $type => $liste): ?>
        <h2 class="mt-5"><?= libelleType($type) ?></h2>
        <?php if (empty($liste)): ?>
            <p>Aucun produit dans cette catégorie.</p>
        <?php else: ?>
            <div id="carousel_<?= $type ?>" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php foreach (array_chunk($liste, 6) as $index => $groupe): ?>
                        <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                            <div class="row justify-content-center">
                                <?php foreach ($groupe as $prod): ?>
                                    <div class="col-md-4 col-lg-2">
                                        <div class="product-card mb-3">
                                            <?php if ($prod['image']): ?>
                                                <img src="<?= htmlspecialchars($prod['image']) ?>" class="img-fluid mb-2" alt="<?= htmlspecialchars($prod['nom']) ?>">
                                            <?php endif; ?>
                                            <h5 class="card-title"><?= htmlspecialchars($prod['nom']) ?></h5>
                                            <p class="prix"><?= number_format($prod['prix'], 2, ',', ' ') ?> €</p>
                                            <a href="detail_produit.php?id=<?= $prod['id'] ?>" class="btn btn-light btn-sm">🔍 Détails</a>
                                            <a href="panier.php?ajouter=<?= (int)$prod['id'] ?>" class="btn btn-outline-light btn-sm">🛒 Ajouter</a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carousel_<?= $type ?>" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carousel_<?= $type ?>" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
